package com.dgs.translateofdgs

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Image as ImageIcon
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TranslateDgsApp() }
    }
}

private enum class Screen { HOME, TEXT, PHOTO, CAMERA, SCREEN, VOICE, DIALOGUE, HISTORY, SETTINGS }
private data class Language(val trName: String, val enName: String, val code: String, val localeTag: String)
private data class Entry(val src: String, val tr: String, val photo: Boolean, val time: Long)
private data class DialogueTurn(val speakerA: Boolean, val original: String, val translated: String, val fromLabel: String, val toLabel: String)
private class Pal(
    val bg: Color, val card: Color, val border: Color, val ink: Color,
    val muted: Color, val tq: Color, val dark: Boolean,
)

private val darkPal = Pal(Color(0xFF050B0E), Color(0xFF0E1A1F), Color(0xFF1F3A40), Color.White, Color(0xFF9CB4BA), Color(0xFF16E0D3), true)
private val lightPal = Pal(Color(0xFFF4FAFA), Color.White, Color(0xFFCDE9E7), Color(0xFF12343A), Color(0xFF607A80), Color(0xFF0FB5AB), false)
private val onTq = Color(0xFF031316)

// Google Çeviri'deki tüm diller (133 dil - Türkçe ve İngilizce arayüz isimleriyle)
private val langs = listOf(
    Language("Türkçe", "Turkish", "tr", "tr-TR"),
    Language("İngilizce", "English", "en", "en-US"),
    Language("Afrikanca", "Afrikaans", "af", "af-ZA"),
    Language("Almanca", "German", "de", "de-DE"),
    Language("Amharca", "Amharic", "am", "am-ET"),
    Language("Arapça", "Arabic", "ar", "ar-SA"),
    Language("Arnavutça", "Albanian", "sq", "sq-AL"),
    Language("Assamca", "Assamese", "as", "as-IN"),
    Language("Aymaraca", "Aymara", "ay", "ay-BO"),
    Language("Azerice", "Azerbaijani", "az", "az-AZ"),
    Language("Bambaraca", "Bambara", "bm", "bm-ML"),
    Language("Baskça", "Basque", "eu", "eu-ES"),
    Language("Belarusça", "Belarusian", "be", "be-BY"),
    Language("Bengalce", "Bengali", "bn", "bn-BD"),
    Language("Bhojpuri", "Bhojpuri", "bho", "bho-IN"),
    Language("Boşnakça", "Bosnian", "bs", "bs-BA"),
    Language("Bulgarca", "Bulgarian", "bg", "bg-BG"),
    Language("Burmaca (Myanmar)", "Myanmar (Burmese)", "my", "my-MM"),
    Language("Cava Dili", "Javanese", "jv", "jv-ID"),
    Language("Cebuano", "Cebuano", "ceb", "ceb-PH"),
    Language("Chicheva", "Chichewa", "ny", "ny-MW"),
    Language("Çekçe", "Czech", "cs", "cs-CZ"),
    Language("Çince (Basitleştirilmiş)", "Chinese (Simplified)", "zh-CN", "zh-CN"),
    Language("Çince (Geleneksel)", "Chinese (Traditional)", "zh-TW", "zh-TW"),
    Language("Danca", "Danish", "da", "da-DK"),
    Language("Divehi", "Dhivehi", "dv", "dv-MV"),
    Language("Dogri", "Dogri", "doi", "doi-IN"),
    Language("Endonezce", "Indonesian", "id", "id-ID"),
    Language("Ermenice", "Armenian", "hy", "hy-AM"),
    Language("Esperanto", "Esperanto", "eo", "eo"),
    Language("Estonca", "Estonian", "et", "et-EE"),
    Language("Ewe", "Ewe", "ee", "ee-GH"),
    Language("Farsça", "Persian", "fa", "fa-IR"),
    Language("Felemenkçe", "Dutch", "nl", "nl-NL"),
    Language("Filipince (Tagalog)", "Filipino (Tagalog)", "tl", "fil-PH"),
    Language("Fince", "Finnish", "fi", "fi-FI"),
    Language("Fransızca", "French", "fr", "fr-FR"),
    Language("Frizce", "Frisian", "fy", "fy-NL"),
    Language("Galce", "Welsh", "cy", "cy-GB"),
    Language("Galiçyaca", "Galician", "gl", "gl-ES"),
    Language("Ganda (Luganda)", "Luganda", "lg", "lg-UG"),
    Language("Guarani", "Guarani", "gn", "gn-PY"),
    Language("Guceratça", "Gujarati", "gu", "gu-IN"),
    Language("Gürcüce", "Georgian", "ka", "ka-GE"),
    Language("Haiti Kreyolu", "Haitian Creole", "ht", "ht-HT"),
    Language("Hausaca", "Hausa", "ha", "ha-NG"),
    Language("Hawaii Dili", "Hawaiian", "haw", "haw-US"),
    Language("Hırvatça", "Croatian", "hr", "hr-HR"),
    Language("Hintçe", "Hindi", "hi", "hi-IN"),
    Language("Hmong", "Hmong", "hmn", "hmn"),
    Language("İbranice", "Hebrew", "iw", "he-IL"),
    Language("İgbo", "Igbo", "ig", "ig-NG"),
    Language("İlokano", "Ilocano", "ilo", "ilo-PH"),
    Language("İrlandaca", "Irish", "ga", "ga-IE"),
    Language("İskoç Gaelcesi", "Scots Gaelic", "gd", "gd-GB"),
    Language("İspanyolca", "Spanish", "es", "es-ES"),
    Language("İsveççe", "Swedish", "sv", "sv-SE"),
    Language("İtalyanca", "Italian", "it", "it-IT"),
    Language("İzlandaca", "Icelandic", "is", "is-IS"),
    Language("Japonca", "Japanese", "ja", "ja-JP"),
    Language("Kamboçyaca (Khmer)", "Khmer", "km", "km-KH"),
    Language("Kannada", "Kannada", "kn", "kn-IN"),
    Language("Katalanca", "Catalan", "ca", "ca-ES"),
    Language("Kazakça", "Kazakh", "kk", "kk-KZ"),
    Language("Keçuva", "Quechua", "qu", "qu-PE"),
    Language("Kırgızca", "Kyrgyz", "ky", "ky-KG"),
    Language("Kinyarwanda", "Kinyarwanda", "rw", "rw-RW"),
    Language("Konkani", "Konkani", "gom", "gom-IN"),
    Language("Korece", "Korean", "ko", "ko-KR"),
    Language("Korsikaca", "Corsican", "co", "co-FR"),
    Language("Krio", "Krio", "kri", "kri-SL"),
    Language("Kürtçe (Kurmanci)", "Kurdish (Kurmanji)", "ku", "ku-TR"),
    Language("Kürtçe (Sorani)", "Kurdish (Sorani)", "ckb", "ckb-IQ"),
    Language("Laoca", "Lao", "lo", "lo-LA"),
    Language("Latince", "Latin", "la", "la"),
    Language("Lehçe", "Polish", "pl", "pl-PL"),
    Language("Letonca", "Latvian", "lv", "lv-LV"),
    Language("Lingala", "Lingala", "ln", "ln-CD"),
    Language("Litvanca", "Lithuanian", "lt", "lt-LT"),
    Language("Lüksemburgca", "Luxembourgish", "lb", "lb-LU"),
    Language("Macarca", "Hungarian", "hu", "hu-HU"),
    Language("Madagaskarca", "Malagasy", "mg", "mg-MG"),
    Language("Maithili", "Maithili", "mai", "mai-IN"),
    Language("Makedonca", "Macedonian", "mk", "mk-MK"),
    Language("Malayalam", "Malayalam", "ml", "ml-IN"),
    Language("Malayca", "Malay", "ms", "ms-MY"),
    Language("Maltaca", "Maltese", "mt", "mt-MT"),
    Language("Maorice", "Maori", "mi", "mi-NZ"),
    Language("Marathi", "Marathi", "mr", "mr-IN"),
    Language("Meiteilon (Manipuri)", "Meiteilon (Manipuri)", "mni-Mtei", "mni-IN"),
    Language("Mizo", "Mizo", "lus", "lus-IN"),
    Language("Moğolca", "Mongolian", "mn", "mn-MN"),
    Language("Nepalce", "Nepali", "ne", "ne-NP"),
    Language("Norveççe", "Norwegian", "no", "nb-NO"),
    Language("Odia (Oriya)", "Odia (Oriya)", "or", "or-IN"),
    Language("Oromo", "Oromo", "om", "om-ET"),
    Language("Özbekçe", "Uzbek", "uz", "uz-UZ"),
    Language("Pencapça", "Punjabi", "pa", "pa-IN"),
    Language("Peştuca", "Pashto", "ps", "ps-AF"),
    Language("Portekizce", "Portuguese", "pt", "pt-PT"),
    Language("Romence", "Romanian", "ro", "ro-RO"),
    Language("Rusça", "Russian", "ru", "ru-RU"),
    Language("Samoaca", "Samoan", "sm", "sm-WS"),
    Language("Sanskritçe", "Sanskrit", "sa", "sa-IN"),
    Language("Sepedi", "Sepedi", "nso", "nso-ZA"),
    Language("Sesotho", "Sesotho", "st", "st-ZA"),
    Language("Sırpça", "Serbian", "sr", "sr-RS"),
    Language("Sindhi", "Sindhi", "sd", "sd-PK"),
    Language("Sinhala", "Sinhala", "si", "si-LK"),
    Language("Slovakça", "Slovak", "sk", "sk-SK"),
    Language("Slovence", "Slovenian", "sl", "sl-SI"),
    Language("Somalice", "Somali", "so", "so-SO"),
    Language("Sundaca", "Sundanese", "su", "su-ID"),
    Language("Svahili", "Swahili", "sw", "sw-KE"),
    Language("Şona", "Shona", "sn", "sn-ZW"),
    Language("Tacikçe", "Tajik", "tg", "tg-TJ"),
    Language("Tamilce", "Tamil", "ta", "ta-IN"),
    Language("Tatarca", "Tatar", "tt", "tt-RU"),
    Language("Tayca", "Thai", "th", "th-TH"),
    Language("Telugu", "Telugu", "te", "te-IN"),
    Language("Tigrinya", "Tigrinya", "ti", "ti-ET"),
    Language("Tsonga", "Tsonga", "ts", "ts-ZA"),
    Language("Türkmence", "Turkmen", "tk", "tk-TM"),
    Language("Twi (Akan)", "Twi (Akan)", "ak", "ak-GH"),
    Language("Ukraynaca", "Ukrainian", "uk", "uk-UA"),
    Language("Urduca", "Urdu", "ur", "ur-PK"),
    Language("Uygurca", "Uyghur", "ug", "ug-CN"),
    Language("Vietnamca", "Vietnamese", "vi", "vi-VN"),
    Language("Yidiş", "Yiddish", "yi", "yi"),
    Language("Yorubaca", "Yoruba", "yo", "yo-NG"),
    Language("Yunanca", "Greek", "el", "el-GR"),
    Language("Zuluca", "Zulu", "zu", "zu-ZA"),
)

private val regions = listOf(
    "Türkiye (TR)", "Avrupa (EU)", "Amerika Birleşik Devletleri (US)",
    "Birleşik Krallık (UK)", "Rusya & BDT (RU)", "Orta Doğu (MENA)", "Asya-Pasifik (APAC)"
)

private fun langDisplayName(l: Language, appLang: String): String =
    if (appLang == "tr") l.trName else l.enName

private fun t(appLang: String, tr: String, en: String): String =
    if (appLang == "tr") tr else en

private fun loadHistory(ctx: Context): List<Entry> {
    val raw = ctx.getSharedPreferences("dgs_prefs", 0).getString("history", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getString("s"), o.getString("t"), o.optBoolean("p"), o.optLong("d"))
        }
    } catch (_: Exception) { emptyList() }
}


private fun langsToJson(appLang: String): String {
    val arr = JSONArray()
    langs.forEach { l ->
        arr.put(
            JSONObject()
                .put("name", langDisplayName(l, appLang))
                .put("code", l.code)
        )
    }
    return arr.toString()
}

private fun saveHistory(ctx: Context, list: List<Entry>) {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("s", it.src).put("t", it.tr).put("p", it.photo).put("d", it.time)) }
    ctx.getSharedPreferences("dgs_prefs", 0).edit().putString("history", arr.toString()).apply()
}

private fun copyToClipboard(ctx: Context, text: String, appLang: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Çeviri", text))
    Toast.makeText(ctx, t(appLang, "Kopyalandı", "Copied"), Toast.LENGTH_SHORT).show()
}

private fun pasteFromClipboard(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip
    if (clip != null && clip.itemCount > 0) {
        return clip.getItemAt(0).coerceToText(ctx)?.toString() ?: ""
    }
    return ""
}

@Composable
private fun TranslateDgsApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("dgs_prefs", 0) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var textInput by remember { mutableStateOf("") }
    var translated by remember { mutableStateOf("") }
    var recognized by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }

    // Varsayılan başlangıç: İngilizce -> Türkçe (Ana menüden ve tüm ekranlardan değiştirilebilir)
    var source by remember { mutableStateOf(langs[1]) }
    var target by remember { mutableStateOf(langs[0]) }

    var errorText by remember { mutableStateOf("") }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var appLang by remember { mutableStateOf(prefs.getString("app_lang", "tr") ?: "tr") }
    var selectedRegion by remember { mutableStateOf(prefs.getString("region", regions[0]) ?: regions[0]) }
    val history = remember { mutableStateListOf<Entry>().apply { addAll(loadHistory(context)) } }

    // Aksanlı Sesli Okuma (TTS) Motoru
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
            }
        }
        engine
    }
    DisposableEffect(Unit) {
        onDispose {
            try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        }
    }

    fun speakText(text: String, localeTag: String) {
        if (text.isBlank()) return
        val engine = tts ?: return
        if (!ttsReady) {
            Toast.makeText(context, t(appLang, "Ses motoru hazırlanıyor...", "Speech engine preparing..."), Toast.LENGTH_SHORT).show()
            return
        }
        val locale = Locale.forLanguageTag(localeTag)
        val res = engine.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(
                context,
                t(appLang, "Bu dil için cihazda aksan paketi yüklü değil, varsayılan sesle okunuyor.", "Accent pack not installed on device, using default voice."),
                Toast.LENGTH_SHORT
            ).show()
        }
        engine.setSpeechRate(0.95f)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dgs_tts_${System.currentTimeMillis()}")
    }

    fun addEntry(src: String, tr: String, photo: Boolean) {
        if (src.isBlank() || tr.isBlank()) return
        if (history.isNotEmpty() && history.first().src == src && history.first().tr == tr) return
        history.add(0, Entry(src, tr, photo, System.currentTimeMillis()))
        while (history.size > 50) history.removeAt(history.size - 1)
        saveHistory(context, history.toList())
    }

    fun openScreen(s: Screen) {
        screen = s
        errorText = ""
        translated = ""
        recognized = ""
    }

    // Metin yazıldıkça anında otomatik çeviri (500ms debounce)
    LaunchedEffect(textInput, source, target, screen) {
        if (screen == Screen.TEXT) {
            val clean = textInput.trim()
            if (clean.isEmpty()) {
                translated = ""
                isBusy = false
            } else {
                delay(450)
                isBusy = true
                errorText = ""
                translateText(clean, source.code, target.code) { result, ok ->
                    translated = result
                    isBusy = false
                }
            }
        }
    }

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            openScreen(Screen.PHOTO)
            isBusy = true
            try {
                val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (bitmap == null) {
                    errorText = t(appLang, "Fotoğraf okunamadı.", "Could not read photo.")
                    isBusy = false
                } else runOcr(bitmap) { text ->
                    recognized = text
                    if (text.isBlank()) {
                        errorText = t(appLang, "Fotoğrafta yazı bulunamadı.", "No text found in photo.")
                        isBusy = false
                    } else translateText(text, source.code, target.code) { result, ok ->
                        translated = result
                        isBusy = false
                        if (ok) addEntry(text, result, true)
                    }
                }
            } catch (e: Exception) {
                errorText = e.localizedMessage ?: t(appLang, "Fotoğraf açılamadı.", "Could not open photo.")
                isBusy = false
            }
        }
    }

    var pendingVoiceScreen by remember { mutableStateOf(Screen.VOICE) }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScreen(pendingVoiceScreen)
        else errorText = t(appLang, "Sesli çeviri için mikrofon izni gerekli.", "Microphone permission is required for voice translation.")
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScreen(Screen.CAMERA)
        else errorText = t(appLang, "Kamera izni olmadan kamera çevirisi açılamaz.", "Camera permission is required.")
    }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val svc = Intent(context, ScreenTranslateService::class.java)
                .putExtra("code", res.resultCode)
                .putExtra("data", data)
                .putExtra("from", source.code)
                .putExtra("to", target.code)
                .putExtra("fromName", langDisplayName(source, appLang))
                .putExtra("toName", langDisplayName(target, appLang))
                .putExtra("langsJson", langsToJson(appLang))
            ContextCompat.startForegroundService(context, svc)
            Toast.makeText(
                context,
                t(appLang, "Ekran çevirisi açıldı. Çevirmek istediğin uygulamaya geç.", "Screen translation started. Switch to the app you want to translate."),
                Toast.LENGTH_LONG
            ).show()
            (context as? Activity)?.moveTaskToBack(true)
        } else {
            errorText = t(appLang, "Ekran yakalama izni verilmedi.", "Screen capture permission denied.")
        }
    }

    fun startScreenTranslation() {
        errorText = ""
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(
                context,
                t(appLang, "Önce 'Diğer uygulamaların üzerinde göster' iznini aç, sonra geri dönüp tekrar başlat.", "Enable 'Display over other apps' permission first, then return and start again."),
                Toast.LENGTH_LONG
            ).show()
            context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
        } else {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }

    val p = if (darkMode) darkPal else lightPal
    val scheme = if (darkMode) darkColorScheme(primary = p.tq, background = p.bg, surface = p.card)
    else lightColorScheme(primary = p.tq, background = p.bg, surface = p.card)

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = p.bg,
            bottomBar = {
                val tab = when (screen) { Screen.HISTORY -> 1; Screen.SETTINGS -> 2; else -> 0 }
                NavigationBar(containerColor = p.bg) {
                    NavItem(p, tab == 0, Icons.Outlined.Home, t(appLang, "Ana sayfa", "Home")) { openScreen(Screen.HOME) }
                    NavItem(p, tab == 1, Icons.Outlined.History, t(appLang, "Geçmiş", "History")) { openScreen(Screen.HISTORY) }
                    NavItem(p, tab == 2, Icons.Outlined.Settings, t(appLang, "Ayarlar", "Settings")) { openScreen(Screen.SETTINGS) }
                }
            },
        ) { inner ->
            Column(
                Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        p = p, appLang = appLang, history = history,
                        source = source, target = target,
                        onSource = { source = it },
                        onTarget = { target = it },
                        onSwap = { val tmp = source; source = target; target = tmp },
                        onText = { openScreen(Screen.TEXT) },
                        onPhoto = { gallery.launch("image/*") },
                        onCamera = { cameraPermission.launch(Manifest.permission.CAMERA) },
                        onScreen = { openScreen(Screen.SCREEN) },
                        onVoice = {
                            pendingVoiceScreen = Screen.VOICE
                            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onDialogue = {
                            pendingVoiceScreen = Screen.DIALOGUE
                            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        onSettings = { openScreen(Screen.SETTINGS) },
                        onHistory = { openScreen(Screen.HISTORY) },
                        onCopy = { copyToClipboard(context, it, appLang) },
                        onSpeak = { txt, loc -> speakText(txt, loc) },
                    )

                    Screen.TEXT -> {
                        ScreenTitle(p, t(appLang, "Metin çevirisi", "Text translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = {
                                val tmp = source
                                source = target
                                target = tmp
                                if (translated.isNotBlank()) {
                                    val oldTr = translated
                                    textInput = oldTr
                                }
                            }
                        )
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(t(appLang, "Çevrilecek metin (Otomatik çevrilir)", "Text to translate (Auto-translates)")) },
                            minLines = 4,
                            trailingIcon = {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = {
                                            val pasted = pasteFromClipboard(context)
                                            if (pasted.isNotBlank()) {
                                                textInput = pasted
                                            } else {
                                                Toast.makeText(context, t(appLang, "Panoda metin yok", "Clipboard is empty"), Toast.LENGTH_SHORT).show()
                                            }
                                        }) {
                                            Icon(Icons.Outlined.ContentPaste, contentDescription = t(appLang, "Yapıştır", "Paste"), tint = p.tq)
                                        }
                                        if (textInput.isNotEmpty()) {
                                            IconButton(onClick = {
                                                textInput = ""
                                                translated = ""
                                            }) {
                                                Icon(Icons.Outlined.Close, contentDescription = t(appLang, "Temizle", "Clear"), tint = Color(0xFFFF8A80))
                                            }
                                        }
                                    }
                                    if (textInput.isNotBlank()) {
                                        IconButton(onClick = { speakText(textInput, source.localeTag) }) {
                                            Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = t(appLang, "Dinle", "Listen"), tint = p.muted)
                                        }
                                    }
                                }
                            }
                        )
                        PrimaryButton(p, t(appLang, "ÇEVİR VE GEÇMİŞE KAYDET", "TRANSLATE & SAVE"), isBusy, appLang) {
                            isBusy = true; errorText = ""
                            translateText(textInput, source.code, target.code) { result, ok ->
                                translated = result; isBusy = false
                                if (ok) addEntry(textInput, result, false)
                            }
                        }
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = {
                                    copyToClipboard(context, translated, appLang)
                                    addEntry(textInput, translated, false)
                                },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.PHOTO -> {
                        ScreenTitle(p, t(appLang, "Fotoğraf çevirisi", "Photo translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        PrimaryButton(p, t(appLang, "Galeriden fotoğraf seç", "Choose photo from gallery"), isBusy, appLang) { gallery.launch("image/*") }
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = { copyToClipboard(context, translated, appLang) },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.CAMERA -> {
                        ScreenTitle(p, t(appLang, "Kamera çevirisi", "Camera translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        CameraTranslator(
                            p = p,
                            appLang = appLang,
                            sourceCode = source.code,
                            targetCode = target.code,
                            onTranslated = { tr, orig ->
                                translated = tr
                                if (orig.isNotBlank() && tr.isNotBlank()) addEntry(orig, tr, true)
                            },
                            onBusy = { isBusy = it }
                        )
                        if (translated.isNotBlank()) {
                            ResultCard(
                                p = p,
                                title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
                                content = translated,
                                onCopy = { copyToClipboard(context, translated, appLang) },
                                onSpeak = { speakText(translated, target.localeTag) }
                            )
                        }
                    }

                    Screen.VOICE -> {
                        ScreenTitle(p, t(appLang, "Sesli konuşma çevirisi", "Voice speech translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        VoiceTranslatorSection(
                            p = p,
                            appLang = appLang,
                            source = source,
                            target = target,
                            recognized = recognized,
                            translated = translated,
                            onRecognized = { recognized = it },
                            onTranslated = { tr ->
                                translated = tr
                                if (recognized.isNotBlank() && tr.isNotBlank()) {
                                    addEntry(recognized, tr, false)
                                    speakText(tr, target.localeTag)
                                }
                            },
                            onBusy = { isBusy = it },
                            onCopy = { copyToClipboard(context, it, appLang) },
                            onSpeakSource = { speakText(recognized, source.localeTag) },
                            onSpeakTarget = { speakText(translated, target.localeTag) }
                        )
                    }

                    Screen.DIALOGUE -> {
                        ScreenTitle(p, t(appLang, "Canlı diyalog (2 Kişi)", "Live dialogue (2 People)"), appLang) { screen = Screen.HOME }
                        DialogueTranslatorSection(
                            p = p,
                            appLang = appLang,
                            langA = source,
                            langB = target,
                            onLangA = { source = it },
                            onLangB = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp },
                            onSpeak = { txt, loc -> speakText(txt, loc) },
                            onCopy = { copyToClipboard(context, it, appLang) },
                            onSaveHistory = { orig, tr -> addEntry(orig, tr, false) }
                        )
                    }

                    Screen.SCREEN -> {
                        LaunchedEffect(Unit) {
                            source = langs[1] // İngilizce
                            target = langs[0] // Türkçe
                        }
                        ScreenTitle(p, t(appLang, "Ekran çevirisi", "Screen translation"), appLang) { screen = Screen.HOME }
                        LangRow(
                            p = p, appLang = appLang, source = source, target = target,
                            onSource = { source = it },
                            onTarget = { target = it },
                            onSwap = { val tmp = source; source = target; target = tmp }
                        )
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Nasıl çalışır", "How it works"), color = p.ink, fontWeight = FontWeight.Bold)
                            Text(
                                t(
                                    appLang,
                                    "1. Başlat'a bas ve istenen izinleri ver.\n2. Çevirmek istediğin uygulamaya veya oyuna geç.\n3. Yüzen paneldeki Çevir'e bas; ekrandaki yazılar seçtiğin hedef dile çevrilir ve ekranda sabit kalır.\n4. Oto'yu açarsan ekran değiştiğinde otomatik yenilenir, Kapat (✕) tuşuna basınca ekrandaki tüm yazılar anında temizlenir.",
                                    "1. Tap Start and grant permissions.\n2. Switch to the app or game you want to translate.\n3. Tap Translate on the floating bar; screen texts are translated and stay visible until you clear or close.\n4. Enable Auto for continuous updates, tap ✕ to cleanly close everything."
                                ),
                                color = p.muted,
                            )
                        }
                        PrimaryButton(p, t(appLang, "Ekran çevirisini başlat", "Start screen translation"), false, appLang) { startScreenTranslation() }
                        OutlinedButton(
                            onClick = { context.stopService(Intent(context, ScreenTranslateService::class.java)) },
                            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp),
                            border = BorderStroke(1.dp, p.tq),
                        ) { Text(t(appLang, "Durdur", "Stop"), color = p.tq) }
                    }

                    Screen.HISTORY -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.History, null, tint = p.tq)
                            Spacer(Modifier.width(8.dp))
                            Text(t(appLang, "Geçmiş", "History"), color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            if (history.isNotEmpty()) TextButton(onClick = { history.clear(); saveHistory(context, emptyList()) }) {
                                Text(t(appLang, "Temizle", "Clear"), color = p.tq)
                            }
                        }
                        if (history.isEmpty()) Text(t(appLang, "Henüz çeviri yok.", "No translations yet."), color = p.muted)
                        history.forEach { entry ->
                            HistoryRow(
                                p = p,
                                e = entry,
                                onCopy = { txt -> copyToClipboard(context, txt, appLang) },
                                onSpeak = { txt -> speakText(txt, target.localeTag) }
                            )
                        }
                    }

                    Screen.SETTINGS -> {
                        Text(t(appLang, "Ayarlar", "Settings"), color = p.ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)

                        // 1. Uygulama Dili Seçimi (Türkçe ile başlar)
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Uygulama dili seçin", "Select app language"), color = p.ink, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        appLang = "tr"
                                        prefs.edit().putString("app_lang", "tr").apply()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(if (appLang == "tr") 2.dp else 1.dp, if (appLang == "tr") p.tq else p.border),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (appLang == "tr") p.tq.copy(alpha = 0.15f) else Color.Transparent
                                    )
                                ) { Text("Türkçe (Varsayılan)", color = p.ink, fontWeight = if (appLang == "tr") FontWeight.Bold else FontWeight.Normal) }

                                OutlinedButton(
                                    onClick = {
                                        appLang = "en"
                                        prefs.edit().putString("app_lang", "en").apply()
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(if (appLang == "en") 2.dp else 1.dp, if (appLang == "en") p.tq else p.border),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (appLang == "en") p.tq.copy(alpha = 0.15f) else Color.Transparent
                                    )
                                ) { Text("English", color = p.ink, fontWeight = if (appLang == "en") FontWeight.Bold else FontWeight.Normal) }
                            }
                        }

                        // 2. Bölge Seçimi
                        var regionExpanded by remember { mutableStateOf(false) }
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(t(appLang, "Bölge seçimi", "Region selection"), color = p.ink, fontWeight = FontWeight.Bold)
                            Text(
                                t(appLang, "Sesli okuma aksanı ve çeviri sunucu bölgesini optimize eder.", "Optimizes speech accent and translation server region."),
                                color = p.muted, fontSize = 12.sp
                            )
                            Box {
                                OutlinedButton(
                                    onClick = { regionExpanded = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, p.tq)
                                ) {
                                    Text(selectedRegion, color = p.ink, modifier = Modifier.weight(1f))
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.tq)
                                }
                                DropdownMenu(expanded = regionExpanded, onDismissRequest = { regionExpanded = false }) {
                                    regions.forEach { reg ->
                                        DropdownMenuItem(
                                            text = { Text(reg) },
                                            onClick = {
                                                selectedRegion = reg
                                                prefs.edit().putString("region", reg).apply()
                                                regionExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // 3. Görünüm
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp),
                        ) {
                            Text(t(appLang, "Görünüm", "Appearance"), color = p.ink, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    if (darkMode) t(appLang, "Karanlık mod", "Dark mode") else t(appLang, "Aydınlık mod", "Light mode"),
                                    color = p.muted, modifier = Modifier.weight(1f)
                                )
                                Switch(checked = darkMode, onCheckedChange = {
                                    darkMode = it
                                    prefs.edit().putBoolean("dark_mode", it).apply()
                                })
                            }
                        }

                        // 4. Bize Ulaşın (Ayrı kart: Instagram, Telegram, E-posta)
                        ContactUsCard(p, appLang)

                        // 5. En Altta: Tasarım & Geliştirme (Deniz Gökmer Söğüt) + Telif Hakkı
                        DeveloperFooterCard(p, appLang)
                    }
                }
                if (isBusy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = p.tq)
                if (errorText.isNotBlank()) Text(errorText, color = Color(0xFFFF8B8B))
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(p: Pal, selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = p.tq, selectedTextColor = p.tq,
            unselectedIconColor = p.muted, unselectedTextColor = p.muted,
            indicatorColor = Color.Transparent,
        ),
    )
}


private val turkishProverbs = listOf(
    "Damlaya damlaya göl olur.",
    "Ağaç yaşken eğilir.",
    "Sakla samanı, gelir zamanı.",
    "Bir elin nesi var, iki elin sesi var.",
    "İşleyen demir ışıldar.",
    "Gülme komşuna, gelir başına.",
    "Acele işe şeytan karışır.",
    "Ak akçe kara gün içindir.",
    "Bakarsan bağ, bakmazsan dağ olur.",
    "Tatlı dil yılanı deliğinden çıkarır.",
    "Bugünün işini yarına bırakma.",
    "Emek olmadan yemek olmaz.",
    "İyilik eden iyilik bulur.",
    "Komşu komşunun külüne muhtaçtır.",
    "Ne ekersen onu biçersin.",
    "Sabrın sonu selamettir.",
    "Üzüm üzüme baka baka kararır.",
    "Yalnız taş duvar olmaz.",
    "Zararın neresinden dönülse kârdır.",
    "Dost kara günde belli olur.",
    "Her işte bir hayır vardır.",
    "Azıcık aşım kaygısız başım.",
    "Güneş girmeyen eve doktor girer.",
    "Hamama giren terler.",
    "İki dinle bir söyle.",
    "Körle yatan şaşı kalkar.",
    "Lafla peynir gemisi yürümez.",
    "Meyve veren ağaç taşlanır.",
    "Öfke ile kalkan zararla oturur.",
    "Rüzgâr eken fırtına biçer.",
    "Söz gümüşse sükût altındır.",
    "Taşıma su ile değirmen dönmez.",
    "Umut fakirin ekmeğidir.",
    "Vakit nakittir.",
    "Yalancının mumu yatsıya kadar yanar.",
    "Zaman her şeyin ilacıdır.",
    "Aslan yattığı yerden belli olur.",
    "Büyük lokma ye büyük söz konuşma.",
    "Çobansız koyunu kurt kapar.",
    "Dağ dağa kavuşmaz, insan insana kavuşur.",
    "El elden üstündür.",
    "Fırsat her zaman ele geçmez.",
    "Görünen köy kılavuz istemez.",
    "Her koyun kendi bacağından asılır.",
    "İğneyi kendine çuvaldızı başkasına batır.",
    "Kendi düşen ağlamaz.",
    "Mart kapıdan baktırır, kazma kürek yaktırır.",
    "Nasihat tutmayan musibet çeker.",
    "Olmayacak duaya âmin denmez.",
    "Paça ıslanmadan balık tutulmaz."
)

@Composable
private fun ProverbCard(
    p: Pal,
    appLang: String,
    onCopy: (String) -> Unit,
    onSpeak: (String, String) -> Unit
) {
    var index by remember { mutableStateOf((turkishProverbs.indices).random()) }
    var trToEn by remember { mutableStateOf(true) } // Öncelik Türkçe -> İngilizce
    var translatedProverb by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    // Otomatik dönen atasözü (her 12 saniyede bir sonraki atasözüne geçer)
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(12000)
            index = (index + 1) % turkishProverbs.size
        }
    }

    val currentTr = turkishProverbs[index]

    LaunchedEffect(index, trToEn) {
        loading = true
        if (trToEn) {
            translateText(currentTr, "tr", "en") { res, _ ->
                translatedProverb = res
                loading = false
            }
        } else {
            // Önce İngilizce karşılığını alıp EN -> TR göster
            translateText(currentTr, "tr", "en") { enRes, ok ->
                if (ok && enRes.isNotBlank()) {
                    translatedProverb = enRes
                }
                loading = false
            }
        }
    }

    val topText = if (trToEn) currentTr else (if (translatedProverb.isNotBlank()) translatedProverb else currentTr)
    val bottomText = if (trToEn) (if (translatedProverb.isNotBlank()) translatedProverb else "…") else currentTr
    val topLocale = if (trToEn) "tr-TR" else "en-US"
    val bottomLocale = if (trToEn) "en-US" else "tr-TR"

    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp))
            .clickable { index = (index + 1) % turkishProverbs.size }
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                t(appLang, "Günün Türk Atasözü", "Turkish Proverb"),
                color = p.tq,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
            // Sağ üstte dil değiştirmedeki butonun aynısı (Türkçe <-> İngilizce)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    if (trToEn) "TR → EN" else "EN → TR",
                    color = p.muted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(p.bg)
                        .border(1.dp, p.tq, CircleShape)
                        .clickable { trToEn = !trToEn },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.SwapHoriz,
                        contentDescription = t(appLang, "Yönü değiştir", "Swap direction"),
                        tint = p.tq,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "“$topText”",
                color = p.ink,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { onSpeak(topText, topLocale) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.muted, modifier = Modifier.size(18.dp))
            }
        }

        Box(Modifier.fillMaxWidth().height(1.dp).background(p.border.copy(alpha = 0.6f)))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (loading && translatedProverb.isBlank()) t(appLang, "Çevriliyor…", "Translating…") else bottomText,
                color = p.tq,
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { onSpeak(bottomText, bottomLocale) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.tq, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = { onCopy(bottomText) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun HomeScreen(
    p: Pal, appLang: String, history: List<Entry>,
    source: Language, target: Language,
    onSource: (Language) -> Unit, onTarget: (Language) -> Unit, onSwap: () -> Unit,
    onText: () -> Unit, onPhoto: () -> Unit, onCamera: () -> Unit, onScreen: () -> Unit,
    onVoice: () -> Unit, onDialogue: () -> Unit,
    onSettings: () -> Unit, onHistory: () -> Unit,
    onCopy: (String) -> Unit, onSpeak: (String, String) -> Unit,
) {
    Box(Modifier.fillMaxWidth().height(116.dp)) {
        WaveBackground(p, Modifier.matchParentSize())
        Row(Modifier.fillMaxWidth().align(Alignment.TopCenter), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.dgs_logo), contentDescription = null, modifier = Modifier.size(82.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Translate", color = p.ink, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
                Text("of DGS", color = p.tq, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 29.sp)
                Text(t(appLang, "Akıllı çeviri merkezi", "Smart translation hub"), color = p.muted, fontSize = 13.sp)
                Box(Modifier.padding(top = 4.dp).width(60.dp).height(2.dp).background(p.tq))
            }
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, p.tq, RoundedCornerShape(12.dp)).clickable { onSettings() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Settings, contentDescription = t(appLang, "Ayarlar", "Settings"), tint = p.tq) }
        }
    }

    // Ana Menü Genel Dil Seçim Alanı (Başlangıç: İngilizce -> Türkçe, tüm çeviri alanlarına referans olur)
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            t(appLang, "Çeviri Dilleri (Tüm modlar için aktif)", "Translation Languages (Active for all modes)"),
            color = p.muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
        LangRow(p, appLang, source, target, onSource, onTarget, onSwap)
    }

    Box(
        Modifier.fillMaxWidth().height(122.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(p.card, if (p.dark) Color(0xFF0A2A30) else Color(0xFFE2F7F5))))
            .border(1.dp, p.border, RoundedCornerShape(20.dp)).clickable { onText() },
    ) {
        Image(
            painterResource(R.drawable.dgs_globe), contentDescription = null,
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(185.dp),
            contentScale = ContentScale.Crop,
        )
        Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(60.dp).clip(RoundedCornerShape(2.dp)).background(p.tq))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(t(appLang, "Anında çevir", "Instant translate"), color = p.ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(
                    t(appLang, "Dilediğin metni hızlıca\nkendi diline çevir", "Quickly translate any text\ninto your language"),
                    color = p.muted, fontSize = 13.sp
                )
            }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.Description, t(appLang, "Metin çevirisi", "Text translate"), Modifier.weight(1f), onText)
        TileCard(p, Icons.Outlined.PhotoCamera, t(appLang, "Kamera", "Camera"), Modifier.weight(1f), onCamera)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.ImageIcon, t(appLang, "Fotoğraf", "Photo"), Modifier.weight(1f), onPhoto)
        TileCard(p, Icons.Outlined.CropFree, t(appLang, "Ekran çevirisi", "Screen translate"), Modifier.weight(1f), onScreen)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        TileCard(p, Icons.Outlined.Mic, t(appLang, "Sesli çeviri", "Voice translate"), Modifier.weight(1f), onVoice)
        TileCard(p, Icons.Outlined.Forum, t(appLang, "Canlı diyalog", "Live dialogue"), Modifier.weight(1f), onDialogue)
    }

    // Sürekli Dönen Türk Atasözü Kartı (Öncelik Türkçe -> İngilizce, sağ üstte dil yönü değiştirme butonlu)
    ProverbCard(p = p, appLang = appLang, onCopy = onCopy, onSpeak = onSpeak)

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.History, null, tint = p.tq)
        Spacer(Modifier.width(8.dp))
        Text(t(appLang, "Son çeviriler", "Recent translations"), color = p.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Row(Modifier.clickable { onHistory() }, verticalAlignment = Alignment.CenterVertically) {
            Text(t(appLang, "Tümünü gör", "See all"), color = p.tq, fontSize = 14.sp)
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.tq)
        }
    }
    if (history.isEmpty()) Text(
        t(appLang, "Henüz çeviri yok. İlk çevirini yaptığında burada görünecek.", "No translations yet. They will appear here."),
        color = p.muted, fontSize = 13.sp
    )
    history.take(2).forEach { HistoryRow(p, it, onCopy, { txt -> onSpeak(txt, target.localeTag) }) }
}

@Composable
private fun TileCard(p: Pal, icon: ImageVector, title: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp)).clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = p.tq, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.ink, fontWeight = FontWeight.Medium, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }
    }
}

@Composable
private fun HistoryRow(p: Pal, e: Entry, onCopy: (String) -> Unit, onSpeak: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (e.photo) Icons.Outlined.ImageIcon else Icons.Outlined.Description, null, tint = p.ink, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.src, color = p.ink, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text("→ ${e.tr}", color = p.tq, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        }
        IconButton(onClick = { onSpeak(e.tr) }) { Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.tq) }
        IconButton(onClick = { onCopy(e.tr) }) { Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted) }
    }
}

@Composable
private fun InstagramLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val grad = Brush.linearGradient(
            listOf(Color(0xFFFD5949), Color(0xFFD6249F), Color(0xFF285AEB))
        )
        drawRoundRect(
            brush = grad,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.28f, h * 0.28f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.18f, h * 0.18f),
            size = androidx.compose.ui.geometry.Size(w * 0.64f, h * 0.64f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.18f, h * 0.18f),
            style = Stroke(width = w * 0.085f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.16f,
            style = Stroke(width = w * 0.085f)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.055f,
            center = androidx.compose.ui.geometry.Offset(w * 0.68f, h * 0.32f)
        )
    }
}

@Composable
private fun TelegramLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawCircle(color = Color(0xFF29A9EB))
        val plane = Path().apply {
            moveTo(w * 0.22f, h * 0.49f)
            lineTo(w * 0.75f, h * 0.28f)
            lineTo(w * 0.65f, h * 0.74f)
            lineTo(w * 0.47f, h * 0.61f)
            lineTo(w * 0.39f, h * 0.69f)
            lineTo(w * 0.39f, h * 0.56f)
            lineTo(w * 0.64f, h * 0.35f)
            lineTo(w * 0.34f, h * 0.53f)
            close()
        }
        drawPath(plane, color = Color.White)
    }
}

@Composable
private fun MailLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            color = Color(0xFFEA4335),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.24f, h * 0.24f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.16f, h * 0.25f),
            size = androidx.compose.ui.geometry.Size(w * 0.68f, h * 0.50f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.08f, h * 0.08f),
            style = Stroke(width = w * 0.08f)
        )
        val flap = Path().apply {
            moveTo(w * 0.18f, h * 0.28f)
            lineTo(w * 0.50f, h * 0.54f)
            lineTo(w * 0.82f, h * 0.28f)
        }
        drawPath(flap, color = Color.White, style = Stroke(width = w * 0.08f))
    }
}

@Composable
private fun ContactUsCard(p: Pal, appLang: String) {
    val context = LocalContext.current
    fun openUrl(url: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(context, t(appLang, "Bağlantı açılamadı.", "Could not open link."), Toast.LENGTH_SHORT).show()
        }
    }
    fun sendEmail() {
        val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:denizgokmersogut@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "Translate of DGS - İletişim")
        }
        try {
            context.startActivity(mailIntent)
        } catch (_: Exception) {
            Toast.makeText(context, t(appLang, "E-posta uygulaması bulunamadı.", "No email app found."), Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            t(appLang, "Bize Ulaşın", "Contact Us"),
            color = p.ink,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        // Instagram
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(p.bg.copy(alpha = 0.6f))
                .clickable { openUrl("https://instagram.com/Denizgokmersogut") }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            InstagramLogo(Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Instagram", color = p.muted, fontSize = 11.sp)
                Text("@Denizgokmersogut", color = p.tq, fontSize = 14.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.Underline)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }

        // Telegram
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(p.bg.copy(alpha = 0.6f))
                .clickable { openUrl("https://t.me/Denizgokmersogut") }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TelegramLogo(Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Telegram", color = p.muted, fontSize = 11.sp)
                Text("@Denizgokmersogut", color = p.tq, fontSize = 14.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.Underline)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }

        // E-posta
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(p.bg.copy(alpha = 0.6f))
                .clickable { sendEmail() }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MailLogo(Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t(appLang, "E-posta", "Email"), color = p.muted, fontSize = 11.sp)
                Text("denizgokmersogut@gmail.com", color = p.tq, fontSize = 14.sp, fontWeight = FontWeight.Medium, textDecoration = TextDecoration.Underline)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = p.muted)
        }
    }
}

@Composable
private fun DeveloperFooterCard(p: Pal, appLang: String) {
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.card)
            .border(1.dp, p.tq, RoundedCornerShape(18.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Person, null, tint = p.tq, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(t(appLang, "Tasarım & Geliştirme", "Design & Development"), color = p.muted, fontSize = 11.sp)
                Text("Deniz Gökmer Söğüt", color = p.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.border))
        Text(
            "Telif Hakkı © 2026 Denizgokmersogut - Tüm Hakları Saklıdır.",
            color = p.muted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ScreenTitle(p: Pal, title: String, appLang: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text(t(appLang, "‹ Geri", "‹ Back"), color = p.tq) }
        Text(title, color = p.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun PrimaryButton(p: Pal, title: String, loading: Boolean, appLang: String, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = !loading, modifier = Modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(25.dp),
        colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq),
    ) { Text(if (loading) t(appLang, "İŞLENİYOR…", "PROCESSING…") else title, fontWeight = FontWeight.Bold) }
}

@Composable
private fun ResultCard(p: Pal, title: String, content: String, onCopy: (() -> Unit)?, onSpeak: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(16.dp)).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = p.tq, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (onSpeak != null) {
                IconButton(onClick = onSpeak) {
                    Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Sesli Oku", tint = p.tq)
                }
            }
            if (onCopy != null) {
                IconButton(onClick = onCopy) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted)
                }
            }
        }
        Text(content, color = p.ink, fontSize = 16.sp)
    }
}

@Composable
private fun LangRow(
    p: Pal, appLang: String, source: Language, target: Language,
    onSource: (Language) -> Unit, onTarget: (Language) -> Unit, onSwap: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        LangPicker(p, appLang, t(appLang, "Kaynak", "From"), source, onSource, Modifier.weight(1f))
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(p.card)
                .border(1.dp, p.tq, CircleShape)
                .clickable { onSwap() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.SwapHoriz, contentDescription = t(appLang, "Dilleri değiştir", "Swap languages"), tint = p.tq)
        }
        LangPicker(p, appLang, t(appLang, "Hedef", "To"), target, onTarget, Modifier.weight(1f))
    }
}

@Composable
private fun LangPicker(p: Pal, appLang: String, label: String, selected: Language, onSelect: (Language) -> Unit, modifier: Modifier) {
    var showDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    Box(modifier) {
        OutlinedButton(
            onClick = { searchQuery = ""; showDialog = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, p.tq),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
        ) {
            Text(
                "$label: ${langDisplayName(selected, appLang)}",
                color = p.ink, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp
            )
        }
    }

    if (showDialog) {
        val filtered = remember(searchQuery, appLang) {
            val q = searchQuery.trim().lowercase()
            if (q.isEmpty()) langs
            else langs.filter {
                it.trName.lowercase().contains(q) ||
                it.enName.lowercase().contains(q) ||
                it.code.lowercase().contains(q)
            }
        }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            containerColor = p.card,
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "$label (${langs.size} ${t(appLang, "Dil", "Languages")})",
                            color = p.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { showDialog = false }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Kapat", tint = p.muted)
                        }
                    }
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text(t(appLang, "Dil ara… (Örn: Rusça, Arapça)", "Search language…"), fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Outlined.Search, null, tint = p.tq) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Outlined.Close, null, tint = p.muted)
                                }
                            }
                        }
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (filtered.isEmpty()) {
                        Text(t(appLang, "Dil bulunamadı.", "No language found."), color = p.muted, modifier = Modifier.padding(12.dp))
                    } else {
                        filtered.forEach { l ->
                            val isSelected = l.code == selected.code
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) p.tq.copy(alpha = 0.18f) else Color.Transparent)
                                    .clickable {
                                        onSelect(l)
                                        showDialog = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    langDisplayName(l, appLang),
                                    color = if (isSelected) p.tq else p.ink,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isSelected) {
                                    Text("✓", color = p.tq, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
private fun VoiceTranslatorSection(
    p: Pal, appLang: String, source: Language, target: Language,
    recognized: String, translated: String,
    onRecognized: (String) -> Unit, onTranslated: (String) -> Unit,
    onBusy: (Boolean) -> Unit, onCopy: (String) -> Unit,
    onSpeakSource: () -> Unit, onSpeakTarget: () -> Unit,
) {
    val context = LocalContext.current
    var listening by remember { mutableStateOf(false) }
    var partialText by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("") }

    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(Unit) {
        onDispose {
            try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) { }
        }
    }

    fun stopListening() {
        listening = false
        try { recognizer?.stopListening() } catch (_: Exception) { }
    }

    fun startListening() {
        val sr = recognizer
        if (sr == null) {
            Toast.makeText(context, t(appLang, "Cihazda arka plan ses tanıma desteklenmiyor.", "Background speech recognition unavailable."), Toast.LENGTH_SHORT).show()
            return
        }
        if (listening) {
            stopListening()
            return
        }
        partialText = ""
        statusText = ""
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                statusText = t(appLang, "Dinleniyor, konuşabilirsiniz…", "Listening, speak now…")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                listening = false
                statusText = t(appLang, "Çevriliyor…", "Translating…")
            }
            override fun onError(error: Int) {
                listening = false
                statusText = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        t(appLang, "Ses algılanamadı, tekrar dokunup konuşun.", "No speech detected, tap and try again.")
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        t(appLang, "Ağ bağlantısı hatası.", "Network connection error.")
                    else -> t(appLang, "Ses algılanamadı, tekrar deneyin.", "Could not recognize speech, try again.")
                }
            }
            override fun onResults(results: Bundle?) {
                listening = false
                statusText = ""
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.trim() ?: ""
                if (spoken.isNotBlank()) {
                    partialText = ""
                    onRecognized(spoken)
                    onBusy(true)
                    translateText(spoken, source.code, target.code) { tr, _ ->
                        onTranslated(tr)
                        onBusy(false)
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (partial.isNotBlank()) partialText = partial
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, source.localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, source.localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            listening = true
            sr.startListening(intent)
        } catch (_: Exception) {
            listening = false
        }
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card)
            .border(1.dp, if (listening) Color(0xFFFF5252) else p.border, RoundedCornerShape(18.dp)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(
                    if (listening) Brush.horizontalGradient(listOf(Color(0xFFFF5252), Color(0xFFFF1744)))
                    else Brush.horizontalGradient(listOf(Color(0xFF22E8E0), Color(0xFF12C9CC)))
                )
                .clickable { startListening() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Outlined.Mic,
                contentDescription = "Konuş",
                tint = if (listening) Color.White else onTq,
                modifier = Modifier.size(42.dp)
            )
        }
        Text(
            if (listening) t(appLang, "Dinleniyor… (Durdurmak için dokun)", "Listening… (Tap to stop)")
            else "${langDisplayName(source, appLang)} ${t(appLang, "konuşmak için mikrofona dokun", "tap mic to speak")}",
            color = p.ink, fontWeight = FontWeight.Bold
        )
        if (partialText.isNotBlank()) {
            Text("“$partialText”", color = p.tq, fontSize = 14.sp)
        }
        if (statusText.isNotBlank()) {
            Text(statusText, color = p.muted, fontSize = 12.sp)
        }
        Text(
            "${t(appLang, "Hedef dil:", "Target language:")} ${langDisplayName(target, appLang)}",
            color = p.tq, fontSize = 13.sp
        )
    }

    if (recognized.isNotBlank()) {
        ResultCard(
            p = p,
            title = "${t(appLang, "Konuşulan", "Spoken")} (${langDisplayName(source, appLang)})",
            content = recognized,
            onCopy = { onCopy(recognized) },
            onSpeak = onSpeakSource
        )
    }
    if (translated.isNotBlank()) {
        ResultCard(
            p = p,
            title = "${t(appLang, "Çeviri", "Translation")} (${langDisplayName(target, appLang)})",
            content = translated,
            onCopy = { onCopy(translated) },
            onSpeak = onSpeakTarget
        )
    }
}

@Composable
private fun DialogueTranslatorSection(
    p: Pal, appLang: String,
    langA: Language, langB: Language,
    onLangA: (Language) -> Unit, onLangB: (Language) -> Unit, onSwap: () -> Unit,
    onSpeak: (String, String) -> Unit, onCopy: (String) -> Unit,
    onSaveHistory: (String, String) -> Unit,
) {
    val context = LocalContext.current
    val turns = remember { mutableStateListOf<DialogueTurn>() }
    var listeningSpeaker by remember { mutableStateOf(0) } // 0: none, 1: A, 2: B
    var livePartial by remember { mutableStateOf("") }
    var statusMsg by remember { mutableStateOf("") }

    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(Unit) {
        onDispose {
            try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) { }
        }
    }

    fun speakTurn(isA: Boolean) {
        val sr = recognizer
        if (sr == null) {
            Toast.makeText(context, t(appLang, "Ses tanıma servisi kullanılamıyor.", "Speech recognition unavailable."), Toast.LENGTH_SHORT).show()
            return
        }
        val targetSpeaker = if (isA) 1 else 2
        if (listeningSpeaker == targetSpeaker) {
            listeningSpeaker = 0
            try { sr.stopListening() } catch (_: Exception) { }
            return
        }
        try { sr.cancel() } catch (_: Exception) { }

        val speakLang = if (isA) langA else langB
        val otherLang = if (isA) langB else langA
        listeningSpeaker = targetSpeaker
        livePartial = ""
        statusMsg = "${if (isA) t(appLang, "1. Kişi", "Person 1") else t(appLang, "2. Kişi", "Person 2")} (${langDisplayName(speakLang, appLang)}) ${t(appLang, "dinleniyor…", "listening…")}"

        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listeningSpeaker = targetSpeaker
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                listeningSpeaker = 0
                statusMsg = t(appLang, "Çevriliyor…", "Translating…")
            }
            override fun onError(error: Int) {
                listeningSpeaker = 0
                statusMsg = t(appLang, "Ses anlaşılamadı, tekrar dokunup konuşun.", "Could not hear clearly, tap and speak again.")
            }
            override fun onResults(results: Bundle?) {
                listeningSpeaker = 0
                statusMsg = ""
                livePartial = ""
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.trim() ?: ""
                if (spoken.isNotBlank()) {
                    translateText(spoken, speakLang.code, otherLang.code) { tr, ok ->
                        if (ok && tr.isNotBlank()) {
                            turns.add(
                                0,
                                DialogueTurn(
                                    speakerA = isA,
                                    original = spoken,
                                    translated = tr,
                                    fromLabel = langDisplayName(speakLang, appLang),
                                    toLabel = langDisplayName(otherLang, appLang)
                                )
                            )
                            onSaveHistory(spoken, tr)
                            onSpeak(tr, otherLang.localeTag)
                        }
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val part = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (part.isNotBlank()) livePartial = part
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, speakLang.localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, speakLang.localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            sr.startListening(intent)
        } catch (_: Exception) {
            listeningSpeaker = 0
        }
    }

    LangRow(p, appLang, langA, langB, onLangA, onLangB, onSwap)

    Text(
        t(
            appLang,
            "Sıra sıra konuşun: 1. Kişi konuştuğunda 2. Kişinin diline çevrilip sesli okunur; 2. Kişi konuştuğunda 1. Kişinin diline çevrilip sesli okunur.",
            "Take turns speaking: Person 1 translates & speaks in Person 2's language, and vice versa."
        ),
        color = p.muted, fontSize = 12.sp
    )

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = { speakTurn(true) },
            modifier = Modifier.weight(1f).height(66.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (listeningSpeaker == 1) Color(0xFFFF5252) else p.tq,
                contentColor = if (listeningSpeaker == 1) Color.White else onTq
            )
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (listeningSpeaker == 1) t(appLang, "Dinleniyor…", "Listening…")
                        else t(appLang, "1. Kişi", "Person 1"),
                        fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
                Text(langDisplayName(langA, appLang), fontSize = 12.sp)
            }
        }

        Button(
            onClick = { speakTurn(false) },
            modifier = Modifier.weight(1f).height(66.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (listeningSpeaker == 2) Color(0xFFFF5252) else Color(0xFF1995AD),
                contentColor = Color.White
            )
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Mic, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (listeningSpeaker == 2) t(appLang, "Dinleniyor…", "Listening…")
                        else t(appLang, "2. Kişi", "Person 2"),
                        fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
                Text(langDisplayName(langB, appLang), fontSize = 12.sp)
            }
        }
    }

    if (statusMsg.isNotBlank() || livePartial.isNotBlank()) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.card)
                .border(1.dp, p.tq, RoundedCornerShape(14.dp)).padding(12.dp)
        ) {
            if (statusMsg.isNotBlank()) Text(statusMsg, color = p.tq, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (livePartial.isNotBlank()) Text("“$livePartial”", color = p.ink, fontSize = 14.sp)
        }
    }

    turns.forEach { turn ->
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (turn.speakerA) p.card else p.tq.copy(alpha = 0.14f))
                .border(1.dp, if (turn.speakerA) p.border else p.tq, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${if (turn.speakerA) t(appLang, "1. Kişi", "Person 1") else t(appLang, "2. Kişi", "Person 2")} (${turn.fromLabel} → ${turn.toLabel})",
                    color = p.tq, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    val targetLocale = if (turn.speakerA) langB.localeTag else langA.localeTag
                    onSpeak(turn.translated, targetLocale)
                }) {
                    Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Dinle", tint = p.tq)
                }
                IconButton(onClick = { onCopy(turn.translated) }) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopyala", tint = p.muted)
                }
            }
            Text(turn.original, color = p.muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text(turn.translated, color = p.ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
}

private fun runOcr(bitmap: Bitmap, callback: (String) -> Unit) {
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    recognizer.process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { result -> callback(result.text.trim()) }
        .addOnFailureListener { callback("") }
        .addOnCompleteListener { recognizer.close() }
}

internal fun translateText(text: String, from: String, to: String, callback: (String, Boolean) -> Unit) {
    val mainHandler = Handler(Looper.getMainLooper())
    if (text.isBlank()) { mainHandler.post { callback("", false) }; return }
    if (from == to) { mainHandler.post { callback(text, true) }; return }
    Thread {
        try {
            val encoded = URLEncoder.encode(text, "UTF-8")
            val urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$from&tl=$to&dt=t&q=$encoded"
            val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val outer = JSONArray(response)
            val segments = outer.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segments.length()) {
                val seg = segments.optJSONArray(i)
                if (seg != null && !seg.isNull(0)) {
                    sb.append(seg.getString(0))
                }
            }
            val result = sb.toString().trim()
            if (result.isNotEmpty()) {
                mainHandler.post { callback(result, true) }
            } else {
                mainHandler.post { callback("Çeviri sonucu boş döndü.", false) }
            }
        } catch (_: Exception) {
            mainHandler.post { callback("Çeviri hatası: İnternet bağlantını kontrol et.", false) }
        }
    }.start()
}

@OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
private fun CameraTranslator(
    p: Pal, appLang: String, sourceCode: String, targetCode: String,
    onTranslated: (String, String) -> Unit, onBusy: (Boolean) -> Unit,
) {
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val context = LocalContext.current
    var liveMode by remember { mutableStateOf(true) }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }

    DisposableEffect(Unit) {
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) { }
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analyzer = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                var lastRun = 0L
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                analyzer.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                    val now = System.currentTimeMillis()
                    if (liveMode && now - lastRun > 2200) {
                        lastRun = now
                        val media = imageProxy.image
                        if (media != null) {
                            val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
                            recognizer.process(input).addOnSuccessListener { result ->
                                val text = result.text.trim()
                                if (text.isNotBlank()) {
                                    onBusy(true)
                                    translateText(text, sourceCode, targetCode) { translated, _ ->
                                        onTranslated(translated, text)
                                        onBusy(false)
                                    }
                                }
                            }.addOnCompleteListener { imageProxy.close() }
                        } else imageProxy.close()
                    } else imageProxy.close()
                }
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analyzer)
                } catch (_: Exception) { }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp)),
    )

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = {
                liveMode = false
                onBusy(true)
                imageCapture.takePicture(
                    ContextCompat.getMainExecutor(context),
                    object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val media = image.image
                            if (media != null) {
                                val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                                val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                rec.process(input).addOnSuccessListener { res ->
                                    val txt = res.text.trim()
                                    if (txt.isBlank()) {
                                        onBusy(false)
                                        Toast.makeText(context, t(appLang, "Fotoğrafta yazı algılanamadı.", "No text detected."), Toast.LENGTH_SHORT).show()
                                    } else {
                                        translateText(txt, sourceCode, targetCode) { tr, _ ->
                                            onTranslated(tr, txt)
                                            onBusy(false)
                                        }
                                    }
                                }.addOnFailureListener {
                                    onBusy(false)
                                }.addOnCompleteListener {
                                    rec.close()
                                    image.close()
                                }
                            } else {
                                onBusy(false)
                                image.close()
                            }
                        }

                        override fun onError(exception: ImageCaptureException) {
                            onBusy(false)
                            Toast.makeText(context, t(appLang, "Fotoğraf çekilemedi.", "Failed to capture photo."), Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            },
            modifier = Modifier.weight(1f).height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = p.tq, contentColor = onTq)
        ) {
            Icon(Icons.Outlined.PhotoCamera, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(t(appLang, "Fotoğraf Çek & Çevir", "Capture & Translate"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        OutlinedButton(
            onClick = { liveMode = !liveMode },
            modifier = Modifier.height(48.dp),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, p.tq)
        ) {
            Text(
                if (liveMode) t(appLang, "Canlı: Açık", "Live: On") else t(appLang, "Canlı: Kapalı", "Live: Off"),
                color = p.tq, fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun WaveBackground(p: Pal, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val glow = if (p.dark) 1f else 0.6f
        fun band(y0: Float, c1: Float, c2: Float, y1: Float, thick: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
                cubicTo(w * 0.65f, c2 + thick, w * 0.35f, c1 + thick, 0f, y0 + thick * 0.3f)
                close()
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w))
        }
        fun line(y0: Float, c1: Float, c2: Float, y1: Float, width: Float, alpha: Float) {
            val path = Path().apply {
                moveTo(0f, y0)
                cubicTo(w * 0.35f, c1, w * 0.65f, c2, w, y1)
            }
            drawPath(path, Brush.horizontalGradient(listOf(Color.Transparent, p.tq.copy(alpha = alpha * glow)), startX = w * 0.15f, endX = w), style = Stroke(width = width))
        }
        band(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, h * 0.22f, 0.28f)
        band(h * 1.15f, h * 1.15f, h * 0.45f, h * 0.35f, h * 0.12f, 0.18f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 14f, 0.10f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 6f, 0.30f)
        line(h * 1.05f, h * 1.1f, h * 0.25f, h * 0.2f, 2.5f, 0.90f)
        line(h * 1.12f, h * 1.15f, h * 0.4f, h * 0.3f, 2f, 0.55f)
    }
}
